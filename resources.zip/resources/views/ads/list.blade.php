@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           Anzeigenverwaltung nicht genehmigt
        </div>


        <div class="panel_content">


            <?php
            $Jdf=new \App\lib\Jdf();
            ?>

            <table class="table table-bordered table-striped">
                <tr>
                    <th>Reihe</th>
                    <th>Anzeigentitel</th>
                    <th>Handynummer des Benutzers</th>
                    <th>Datum der Registrierung</th>
                    <th>Aktualisierungsdatum</th>
                    <th>operation</th>
                </tr>
                <?php $i=1; ?>
                @foreach($AdsList as $key=>$value)
                    <tr>

                        <td>{{ $i }}</td>
                        <td>{{ $value->title }}</td>
                        <td>{{ $value->getUser->mobile }}</td>
                        <td>{{ $Jdf->jdate(' H:i:s / Y-n-j',strtotime($value->created_at)) }}</td>
                        <td>{{ $Jdf->jdate(' H:i:s / Y-n-j',strtotime($value->updated_at)) }}</td>
                        <td>
                            <a class="fa fa-eye" href="{{ url('admin/ads').'/'.$value->id.'/show' }}"></a>
                            <a class="fa fa-trash" onclick="del_row('{{ url('admin/ads').'/'.$value->id  }}','{{ Session::token() }}','Möchten Sie diese Anzeige wirklich löschen?')"></a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
            </table>

             {{ $AdsList->links() }}
        </div>
    </div>

@endsection