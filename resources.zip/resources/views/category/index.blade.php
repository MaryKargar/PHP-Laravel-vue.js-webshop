@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           Kategorien verwalten
        </div>


        <div class="panel_content">


            <a class="btn btn-success" href="{{ url('admin/category/create') }}">Neue Kategorie hinzufügen</a>

            <table class="table table-bordered table-striped">
                <tr>
                    <th>Reihe</th>
                    <th>Kategorie name</th>
                    <th>Parent Kategorie </th>
                    <th>operation</th>
                </tr>
                <form method="get">
                <tr>
                    <td></td>
                    <td><input type="text" value="@if(array_key_exists('category_name',$data)){{ $data['category_name'] }}@endif" class="form-control" name="category_name"></td>
                    <td></td>
                    <td></td>
                </tr>
                </form>
                <?php $i=1; ?>
                @foreach($category as $key=>$value)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $value->category_name }}</td>
                        <td>{{ $value->getParent->category_name }}</td>
                        <td>
                            <a class="fa fa-edit" href="{{ url('admin/category').'/'.$value->id.'/edit' }}"></a>
                            <a class="fa fa-trash" onclick="del_row('{{ url('admin/category').'/'.$value->id  }}','{{ Session::token() }}','Möchten Sie diese Kategorie wirklich löschen?')"></a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
            </table>

             {{ $category->links() }}
        </div>
    </div>

@endsection