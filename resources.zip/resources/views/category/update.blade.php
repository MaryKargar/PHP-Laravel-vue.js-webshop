@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           Kategorie bearbeiten {{ $category->category_name }}
        </div>


        <div class="panel_content">

           {{ Form::model($category,['url'=>'admin/category/'.$category->id,'files'=>true]) }}


            {{ method_field('PUT') }}
            <div class="form-group">

                {{ Form::label('category_name','Kategorie name: ') }}
                {{ Form::text('category_name',null,['class'=>'form-control']) }}
                @if($errors->has('category_name'))
                    <p class="has_error">{{ $errors->first('category_name') }}</p>
                @endif
            </div>

            <div class="form-group">

                {{ Form::label('parent_id','Kategorie 1 : ') }}
                {{ Form::select('parent_id',$catList,null,['class'=>'selectpicker','data-live-search'=>'true']) }}
            </div>


            <p class="has_error">Durch Hinzufügen dieses Teils werden der im Suchformular registrierte Filter und die Registrierung von Anzeigen für diese Kategorie nicht angezeigt</p>

            <div class="form-group">

                {{ Form::label('without_filter_id','Anzeigeende mit ID filtern: ') }}
                {{ Form::text('without_filter_id',null,['class'=>'form-control']) }}
            </div>

            <div class="form-group">

                {{ Form::label('pic','اKategorie-ICON : ') }}
                {{ Form::file('pic') }}
                @if($errors->has('pic'))
                    <p class="has_error">{{ $errors->first('pic') }}</p>
                @endif
            </div>

            <div class="form-group">
                <button class="btn btn-primary">Bearbeiten</button>
            </div>
            {{ Form::close() }}

        </div>

    </div>

@endsection