@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
            Benutzer verwaltung
        </div>


        <div class="panel_content">
            Benutzer Liste
        </div>

    </div>

@endsection