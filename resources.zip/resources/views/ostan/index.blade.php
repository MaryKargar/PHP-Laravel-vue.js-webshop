@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           ORT verwaltung
        </div>


        <div class="panel_content">


            <a class="btn btn-success" href="{{ url('admin/location/ostan/create') }}">افزودن استان جدید</a>

            <table class="table table-bordered table-striped">
                <tr>
                    <th>Reife</th>
                    <th>ORT name</th>
                    <th>operation</th>
                </tr>
                <form method="get">
                <tr>
                    <td></td>
                    <td><input type="text" value="@if(array_key_exists('ostan_name',$data)) {{ $data['ostan_name'] }}@endif" class="form-control" name="ostan_name"></td>
                    <td></td>
                </tr>
                </form>
                <?php $i=1; ?>
                @foreach($ostan as $key=>$value)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $value->ostan_name }}</td>
                        <td>
                            <a class="fa fa-edit" href="{{ url('admin/location/ostan').'/'.$value->id.'/edit' }}"></a>
                            <a class="fa fa-trash" onclick="del_row('{{ url('admin/location/ostan').'/'.$value->id  }}','{{ Session::token() }}','آیا از حذف این استان مطمین هستین !')"></a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
            </table>

             {{ $ostan->links() }}
        </div>
    </div>

@endsection