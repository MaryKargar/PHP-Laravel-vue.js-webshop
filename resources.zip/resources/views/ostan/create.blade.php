@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
            ORT hinzufügen
        </div>


        <div class="panel_content">

           {{ Form::open(['url'=>'admin/location/ostan']) }}


            <div class="form-group">

                {{ Form::label('ostan_name','ORT name : ') }}
                {{ Form::text('ostan_name',null,['class'=>'form-control']) }}
                @if($errors->has('ostan_name'))
                    <p class="has_error">{{ $errors->first('ostan_name') }}</p>
                @endif
            </div>





            <div class="form-group">
                <button class="btn btn-success">registerieren</button>
            </div>
            {{ Form::close() }}

        </div>

    </div>

@endsection