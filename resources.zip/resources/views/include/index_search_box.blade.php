<div class="index_search_box">


    <div class="col-4">
        <input type="text" name="" class="form-control"  placeholder="suchen ...">
    </div>
    <div class="select_box form-control col-3" id="select_cat">
        <span class="box_title">
            @if(isset($cat_name))
                {{ $cat_name  }}
                @else
                Alle Gruppen
            @endif
        </span>
        <span class="fa fa-angle-down"></span>
    </div>

    <div class="select_box form-control col-3">
        <span class="box_title">alle AT</span>
        <span class="fa fa-angle-down"></span>
    </div>

    <div class="col-2 btn_search">
        <div>
            <span class="fa fa-search"></span>
            <span>جsuchen</span>
        </div>
    </div>

    <div style="clear:both"></div>
</div>