@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           ORTleitung
        </div>


        <div class="panel_content">


            <a class="btn btn-success" href="{{ url('admin/location/area/create') }}">افزودن شهر جدید</a>

            <table class="table table-bordered table-striped">
                <tr>
                    <th>Reihe</th>
                    <th>ORT</th>
                    <th>Stadt</th>
                    <th>Operation</th>
                </tr>
                <form method="get">
                <tr>
                    <td></td>
                    <td><input type="text" value="@if(array_key_exists('area_name',$data)) {{ $data['area_name'] }}@endif" class="form-control" name="area_name"></td>
                    <td></td>
                </tr>
                </form>
                <?php $i=1; ?>
                @foreach($area as $key=>$value)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $value->area_name }}</td>
                        <td>{{ $value->getShahr->shahr_name }}</td>
                        <td>
                            <a class="fa fa-edit" href="{{ url('admin/location/area').'/'.$value->id.'/edit' }}"></a>
                            <a class="fa fa-trash" onclick="del_row('{{ url('admin/location/area').'/'.$value->id  }}','{{ Session::token() }}','آیا از حذف این منطقه مطمین هستین !')"></a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
            </table>

             {{ $area->links() }}
        </div>
    </div>

@endsection