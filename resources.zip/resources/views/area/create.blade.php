@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
            ORT hinzufügen
        </div>


        <div class="panel_content">

           {{ Form::open(['url'=>'admin/location/area']) }}


            <div class="form-group">

                {{ Form::label('area_name','ORT name: ') }}
                {{ Form::text('area_name',null,['class'=>'form-control']) }}
                @if($errors->has('area_name'))
                    <p class="has_error">{{ $errors->first('area_name') }}</p>
                @endif
            </div>


            <div class="form-group">

                {{ Form::label('shahr_id','Wählen Sie eine Stadt aus : ') }}
                {{ Form::select('shahr_id',$shahr,null,['class'=>'selectpicker','data-live-search'=>'true']) }}
            </div>



            <div class="form-group">
                <button class="btn btn-success">Register</button>
            </div>
            {{ Form::close() }}

        </div>

    </div>

@endsection