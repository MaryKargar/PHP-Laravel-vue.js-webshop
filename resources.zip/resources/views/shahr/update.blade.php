@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
             Stadtnamen bearbeiten - {{ $shahr->shahr_name }}
        </div>


        <div class="panel_content">

           {{ Form::model($shahr,['url'=>'admin/location/shahr/'.$shahr->id]) }}


            {{ method_field('PUt') }}
            <div class="form-group">

                {{ Form::label('shahr_name','Stadt name: ') }}
                {{ Form::text('shahr_name',null,['class'=>'form-control']) }}
                @if($errors->has('shahr_name'))
                    <p class="has_error">{{ $errors->first('shahr_name') }}</p>
                @endif
            </div>

            <div class="form-group">

                {{ Form::label('ostan_id','ORT Wählen : ') }}
                {{ Form::select('ostan_id',$ostan,null,['class'=>'selectpicker','data-live-search'=>'true']) }}
            </div>



            <div class="form-group">
                <button class="btn btn-primary">Bearbeiten</button>
            </div>
            {{ Form::close() }}

        </div>

    </div>

@endsection