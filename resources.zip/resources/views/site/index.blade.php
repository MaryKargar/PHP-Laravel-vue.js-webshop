@extends('layouts.site')

@section('content')


    <div class="header">

        <p>Kostenlose Anforderungen</p>
        <p>

           Kaufen und verkaufen Sie Autos, Immobilien, Wohnungen, Mobiltelefone, Tablets, Haushaltsgeräte, Gebrauchtgeräte, Mieten und alles, was Ihnen einfällt
        </p>
    </div>


    @include('include.index_search_box')
    @include('include.CatList',['catList'=>$catList])



    @include('include.adsCatList',['catList'=>$catList])







    <div  class="content">


        <h5 class="color-gray">Die neusten Anzeigen</h5>

        @include('include.ads',['ads'=>$newAds])

    </div>

@endsection