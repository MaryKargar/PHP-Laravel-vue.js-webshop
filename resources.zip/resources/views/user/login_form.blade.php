@extends('layouts.site')

@section('content')


    <div class="login_box">

        @if(Session::get('status')=='ok')

           <div id="active_box">
               <h5>Handynummer bestätigen</h5>
               <p class="gray">6-stelliger Code an Handynummer gesendet {{ Session::get('login_mobile_number') }} Eingeben</p>


               <div class="form-group">

                   <form method="post" id="active_form" action="{{ url('active_code') }}">
                       {{ csrf_field() }}

                       <p class="active_form_span">
                           <span>Aktivierungscode erneut senden</span>

                           <span class="active_form_span left">Korrektur der Handynummer</span>
                       </p>

                       <div class="number_input_div">
                           <input type="text" name="active_code" id="active_code" value="{{ old('active_code') }}" class="number_input number" maxlength="6">
                       </div>


                       <div class="line_box">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>


                       <p class="has_error">

                           {{ Session::get('active_error') }}
                       </p>


                       <div class="form-group">
                           <div id="btn_active_code" class="btn btn-primary">Endgültige Genehmigung und Wort zu den Anforderungen</div>
                       </div>
                   </form>
               </div>
           </div>
        @endif


            <div id="login_div" @if(Session::get('status')=='ok') style="display:none" @endif>
                <h5>Einloggen / Anmelden </h5>
                <p class="gray">Bitte geben Sie Ihre Handynummer ein, um sich anzumelden oder zu registrieren. </p>

                <form method="post" action="{{ Route('login') }}">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label>Handynummer</label>
                        <input type="text" name="mobile_number" value="{{ old('mobile_number') }}" id="mobile_number" class="form-control number">
                        @if($errors->has('mobile_number'))
                            <p class="has_error">{{ $errors->first('mobile_number') }}</p>
                        @endif
                    </div>




                    <div class="form-group">
                        <button class="btn btn-primary">Melden Sie sich an oder registrieren Sie sich für Anforderungen</button>
                    </div>
                </form>
            </div>

    </div>

@endsection