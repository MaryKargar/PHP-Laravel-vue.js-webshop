@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
            Filter bearbeiten- {{ $filter->filter_name }}
        </div>

        <?php

        $filter_type=array();
        $filter_type[0]='Intervall Filter';
        $filter_type[1]='Selektiver Filter';
        $filter_type[2]='checkbox Filter';


        $validateType=array();
        $validateType[0]='Zeichenfolge - kann leer sein';
        $validateType[1]='Zeichenfolge - kann nicht leer sein';
        $validateType[2]='Numerisch – kann leer sein';
        $validateType[3]='Numerisch – kann  nicht leer sein';
        ?>

        <div class="panel_content">

           {{ Form::model($filter,['url'=>'admin/ads/filter/'.$filter->id]) }}

            {{ method_field('PUT') }}
            <div class="form-group">

                {{ Form::label('filter_name','Filter name : ') }}
                {{ Form::text('filter_name',null,['class'=>'form-control']) }}
                @if($errors->has('filter_name'))
                    <p class="has_error">{{ $errors->first('filter_name') }}</p>
                @endif
            </div>

            <div class="form-group">

                {{ Form::label('catId','Filtergriff : ') }}
                {{ Form::select('catId',$catList,null,['class'=>'selectpicker','data-live-search'=>'true']) }}
            </div>

            <div class="form-group">

                {{ Form::label('filter_type','Filter Typ : ') }}
                {{ Form::select('filter_type',$filter_type,null,['class'=>'selectpicker']) }}
            </div>



            <div class="form-group">

                {{ Form::label('filter_text','label Filter: ') }}
                {{ Form::text('filter_text',null,['class'=>'form-control']) }}
                @if($errors->has('filter_text'))
                    <p class="has_error">{{ $errors->first('filter_text') }}</p>
                @endif
            </div>

            <div class="form-group">

                {{ Form::label('validateType','Art der Validierung : ') }}
                {{ Form::select('validateType',$validateType,null,['class'=>'selectpicker','data-live-search'=>'true']) }}
            </div>


            <div class="form-group">

                {{ Form::label('show_filter','Als Werbeartikel anzeigen : ') }}
                {{ Form::checkbox('show_filter',null) }}
            </div>


            <div class="form-group">
                <button class="btn btn-primary">Bearbeiten</button>
            </div>
            {{ Form::close() }}

        </div>

    </div>

@endsection