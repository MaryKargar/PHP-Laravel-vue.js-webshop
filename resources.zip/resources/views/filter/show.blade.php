@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
            Filter - {{ $filter->filter_name }}
        </div>

        <?php
        $filter_type=array();
        $filter_type[0]='Intervall Filter';
        $filter_type[1]='Selektiver Filter';
        $filter_type[2]='checkbox Filter';
        ?>

        <div class="panel_content">


            <table class="table table-striped table-bordered">
                <tr>
                    <td style="width: 150px">Filter name</td>
                    <td>{{ $filter->filter_name }}</td>
                </tr>

                <tr>
                    <td style="width: 150px">Filtergriff</td>
                    <td>{{ $filter->getCat->category_name }}</td>
                </tr>

                <tr>
                    <td style="width: 150px">Filter Typ</td>
                    <td>{{ $filter_type[$filter->filter_type] }}</td>
                </tr>

            </table>



            <form method="post" action="{{ url('admin/ads/filter/add_item') }}">
                {{ csrf_field() }}
                <input type="hidden" value="{{ $filter->id }}" name="filter_id">
                <div id="item_box">

                    @foreach($filter->getChild as $key=>$value)

                        <div style="width:100%;float:right;margin-top: 10px">
                            <input type="text" name="item[{{ $value->id }}]" class="form-control filter_item" value="{{ $value->item_name }}" placeholder="Artikeltitel" />
                            <span class="fa fa-trash" onclick="del_row('{{ url('admin/ads/filter/del_item').'/'.$value->id  }}','{{ Session::token() }}','Möchten Sie dieses Element wirklich löschen?')"></span>
                        </div>

                    @endforeach

                    <div style="clear:both"></div>
                </div>
                <button class="btn btn-success add_item_btn" id="add_item_btn">regestrieren</button>
            </form>
            @if(sizeof($filter->getChild)>0)
                <script>
                    document.getElementById('add_item_btn').style.display='block';
                </script>
            @endif
            @if($filter->filter_type!=2)

                <p class="add_item_text" onclick="add_filter_item()">
                    <span class="fa fa-plus"></span>
                    <span>Artikel hinzufügen</span>
                </p>

           @endif

            <div style="clear:both"></div>
        </div>



    </div>
@endsection
