@extends("layouts.admin")

@section('content')

    <div class="panel">

        <div class="header">
           Anzeigenfilter verwalten
        </div>


        <div class="panel_content">


            <a class="btn btn-success" href="{{ url('admin/ads/filter/create') }}">افزودن فیلتر جدید</a>

            <table class="table table-bordered table-striped">
                <tr>
                    <th>Reihe</th>
                    <th>Filter ID</th>
                    <th>نFilter name</th>
                    <th>Filtergriff</th>
                    <th>operation</th>
                </tr>
                <?php $i=1; ?>
                @foreach($filter as $key=>$value)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $value->id }}</td>
                        <td>{{ $value->filter_name }}</td>
                        <td>{{ $value->getCat->category_name }}</td>
                        <td>
                            <a class="fa fa-edit" href="{{ url('admin/ads/filter').'/'.$value->id.'/edit' }}"></a>
                            <a class="fa fa-eye" href="{{ url('admin/ads/filter').'/'.$value->id }}"></a>
                            <a class="fa fa-trash" onclick="del_row('{{ url('admin/ads/filter').'/'.$value->id  }}','{{ Session::token() }}','Möchten Sie diesen Filter wirklich löschen?')"></a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
            </table>

             {{ $filter->links() }}
        </div>
    </div>

@endsection