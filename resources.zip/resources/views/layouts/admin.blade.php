<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Administrationsmenü</title>
    <link href="{{ url('css/app.css') }}" rel="stylesheet">
    <link href="{{ url('css/admin.css') }}" rel="stylesheet">
</head>
<body>



<div class="container-fluid">

    <div class="page_sidebar">

        <span class="fa fa-bars" id="sidebarToggle"></span>
        <ul class="list-inline" id="sidebar_menu">
            <li>
                <a>
                    <span class="fa fa-shopping-cart"></span>
                    <span class="sidebar_menu_span">Anzeigen</span>
                    <span class="fa fa-angle-left"></span>
                </a>
                <div class="child_menu">
                    <a href="">Anzeigen warten auf Genehmigung</a>
                    <a href="">Genehmigte Anzeigen</a>
                    <a href="{{ url('admin/ads/filter') }}">Anzeigenfilter verwalten</a>
                </div>
            </li>

            <li>
                <a>
                    <span class="fa fa-list"></span>
                    <span class="sidebar_menu_span">Kategorien</span>
                    <span class="fa fa-angle-left"></span>
                </a>
                <div class="child_menu">
                    <a href="{{ url('admin/category') }}">Kategorien verwalten</a>
                    <a href="{{ url('admin/category/create') }}">Neue Kategorie hinzufügen</a>
                </div>
            </li>

            <li>
                <a>
                    <span class="fa fa-location-arrow"></span>
                    <span class="sidebar_menu_span">ORT</span>
                    <span class="fa fa-angle-left"></span>
                </a>
                <div class="child_menu">
                    <a href="{{ url('admin/location/ostan') }}">ORT verwalten</a>
                    <a href="{{ url('admin/location/shahr') }}"> Stadt verwalten</a>
                    <a href="{{ url('admin/location/area') }}">PLZ verwalten</a>
                </div>
            </li>

            <li>
                <a>
                    <span class="fa fa-users"></span>
                    <span class="sidebar_menu_span">Benutzer  verwalten</span>
                    <span class="fa fa-angle-left"></span>
                </a>
                <div class="child_menu">
                    <a href="{{ url('admin/users') }}">Benutzer</a>
                    <a href="">Fügen Sie einen neuen Benutzer hinzu</a>
                </div>
            </li>
        </ul>
    </div>

    <div class="page_content">

       <div class="content_box">
           @yield('content')
       </div>

    </div>

    <div class="message_div">

        <div class="message_box">

            <p id="msg"></p>

            <a class="alert alert-success" onclick="delete_row()">Ja</a>
            <a class="alert alert-danger" onclick="hide_box()">Nein</a>
        </div>

    </div>

</div>

<script type="text/javascript" src="{{ url('js/app.js') }}"></script>
<script type="text/javascript" src="{{ url('js/admin.js') }}"></script>
</body>
</html>