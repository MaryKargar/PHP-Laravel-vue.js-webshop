<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anforderungen</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="{{ url('css/app.css') }}" rel="stylesheet">
    <link href="{{ url('css/site.css') }}" rel="stylesheet">
</head>
<body>

<div class="container-fluid">

    <div class="top_line"></div>

    <div class="navbar">

        <ul class="list-inline" id="nab_bar_menu">
            <li><a href="">Alle Anzeigen</a></li>
            <li><a href="">Alle Geschäfte</a></li>
            <li><a href="">Unterstützung</a></li>




            <li class="dropdown_link">
                <a data-toggle="dropdown">
                    <span>Mein Konto</span>
                    <span class="fa fa-user"></span>
                </a>

                <ul class="dropdown-menu dropdown_ul">
                    <li><a class="dropdown-item" href="">Einloggen Anmelden</a></li>
                    <li><div class="dropdown-divider"></div></li>
                    <li><a class="dropdown-item" href="">Favoriten</a></li>
                    <li><a class="dropdown-item" href="">Meine Anzeigen</a></li>
                    <li><a class="dropdown-item" href="">Meine Suchen</a></li>
                </ul>
            </li>
            <li class="add_ads_btn">
                <div>
                    <span class="fa fa-plus"></span>
                    <span>Veröffentlichen Sie eine kostenlose Anzeige</span>
                </div>
            </li>
        </ul>
    </div>




    @yield('content')





    <div style="clear:both"></div>
    <footer id="footer">


        <div style="width:100%;float:right">
            <ul class="list-inline footer_ul">
                <li>Anforderungen</li>
                <li><a href="">
                        Über Anforderungen
                    </a></li>

                <li><a href="">
                        blog
                    </a></li>

                <li><a href="">
                        Seitenverzeichnis
                    </a></li>

            </ul>


            <ul class="list-inline footer_ul">
                <li>Kundenleitfaden</li>
                <li><a href="">
                        Häufig gestellte Fragen
                    </a></li>

                <li><a href="">
                        Geschäftsbedingungen
                    </a></li>

                <li><a href="">
                        Datenschutz
                    </a>
                </li>

            </ul>


            <ul class="list-inline footer_ul">
                <li>Kundenservice</li>
                <li><a href="">
                        Senden Sie Vorschläge
                    </a></li>

                <li><a href="">
                        24-Stunden-Support
                    </a></li>

            </ul>

            <ul class="list-inline footer_ul left">
                <li>
                    <a href="" class="app-badge google-play"></a>
                </li>

                <li>
                    <a href="" class="app-badge app-store"></a>
                </li>

                <li>
                    <a href="" class="app-badge myket"></a>
                </li>
            </ul>

        </div>


        <div style="width:100%;background:#afafaf;float:right">

            <p style="font-size:13px;padding:15px 20px 0px 0px">
               Alle Rechte dieser Seite liegen bei MK.
            </p>
        </div>

    </footer>
</div>

<script type="text/javascript" src="{{ url('js/app.js') }}"></script>
<script type="text/javascript" src="{{ url('js/site.js') }}"></script>
@yield('footer')
</body>
</html>